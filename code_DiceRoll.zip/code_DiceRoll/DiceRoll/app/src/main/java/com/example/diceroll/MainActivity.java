package com.example.diceroll;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    public ImageButton btn_img_roll, btn_img_unpause, btn_img_exit;
    public TextView text_sum, logo_list;
    public TextView result_start;
    public TextView result_end;
    public TextView roll_list_1, roll_list_2, roll_list_3, roll_list_4, roll_list_5;
    public ImageView img_1, img_2;
    public int checkPause = 0, count = 0, rnd1, rnd2;
    public String str = "";

    private final String[] list = new String[] {"", "", "", "", ""};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        img_1 = findViewById(R.id.img_1);
        img_2 = findViewById(R.id.img_2);
        text_sum = findViewById(R.id.text_sum);
        result_start = findViewById(R.id.result_start);
        result_end = findViewById(R.id.result_end);
        btn_img_roll = findViewById(R.id.btn_img_roll);
        btn_img_roll.setOnClickListener(view -> {
            roll();
            pause();
            imgPrint(rnd1, img_1);
            imgPrint(rnd2, img_2);
            resultPrint(rnd1, rnd2);
            listPrint(rnd1, rnd2);
        });
        btn_img_unpause = findViewById(R.id.btn_img_unpause);
        btn_img_unpause.setOnClickListener(view -> unpause());
        btn_img_exit = findViewById(R.id.btn_img_exit);
        btn_img_exit.setOnClickListener(view -> showExit());
        logo_list = findViewById(R.id.logo_list);
        roll_list_1 = findViewById(R.id.roll_list_1);
        roll_list_2 = findViewById(R.id.roll_list_2);
        roll_list_3 = findViewById(R.id.roll_list_3);
        roll_list_4 = findViewById(R.id.roll_list_4);
        roll_list_5 = findViewById(R.id.roll_list_5);
    }
    @Override
    protected void onResume() {
        super.onResume();
        pause();
        imgPrint(rnd1, img_1);
        imgPrint(rnd2, img_2);
        resultPrint(rnd1, rnd2);
        listPrint(rnd1, rnd2);
    }
    public void roll() {
        count++;
        rnd1 = Dice(6);
        rnd2 = Dice(6);
        showMessage("Rolled! Need to action!");
        checkPause = 1;
    }
    public void resultPrint(int rnd1, int rnd2) {
        if (count > 0) {
            result_start.setText(R.string.result_start);
            text_sum.setText(String.valueOf(rnd1 + rnd2));
            result_end.setText(R.string.result_end);
        }
    }
    public void listPrint (int rnd1, int rnd2) {
        if (count > 0) {
            logo_list.setText(R.string.logo_list);
        }
        str = "[" + rnd1 +" : " + rnd2 + "]" + " Got " + (rnd1+rnd2) + " !";
        if (count <= 5) {
            switch (count) {
                case 1:
                    list[0] = str;
                    break;
                case 2:
                    list[1] = str;
                    break;
                case 3:
                    list[2] = str;
                    break;
                case 4:
                    list[3] = str;
                    break;
                case 5:
                    list[4] = str;
                    break;
            }
        }
        if (count > 5) {
            for (int i = 0; i < 4; i++ ) {
                list[i] = list[i+1];
            }
            list[4] = str;
        }
        listCheck(list[0], roll_list_1);
        listCheck(list[1], roll_list_2);
        listCheck(list[2], roll_list_3);
        listCheck(list[3], roll_list_4);
        listCheck(list[4], roll_list_5);
    }
    public void listCheck (String string, TextView textview) {
        if (!Objects.equals(string, "")) {
            textview.setText(string);
            textview.setBackgroundResource(R.color.sum_bg);
        }
    }
    public void imgPrint(int rnd, ImageView imageView) {
        switch (rnd) {
            case 1:
                imageView.setImageResource(R.drawable.dice1);
                break;
            case 2:
                imageView.setImageResource(R.drawable.dice2);
                break;
            case 3:
                imageView.setImageResource(R.drawable.dice3);
                break;
            case 4:
                imageView.setImageResource(R.drawable.dice4);
                break;
            case 5:
                imageView.setImageResource(R.drawable.dice5);
                break;
            case 6:
                imageView.setImageResource(R.drawable.dice6);
                break;
        }
    }
    public int Dice(int numSide) {
        int min = 1;
        return (min + (int) (Math.random() * (numSide - min + 1)));
    }
    public void pause() {
        if (checkPause == 1) {
            btn_img_roll.setEnabled(false);
            btn_img_unpause.setEnabled(true);
        }
    }
    public void unpause() {
        if (checkPause == 0) {
            showMessage("You need to roll first");
            btn_img_roll.setEnabled(true);
        } else {
            showMessage("Next round! You can roll again!");
            btn_img_roll.setEnabled(true);
        }
    }
    public void showMessage(String text) {
        Toast.makeText(MainActivity.this, text, Toast.LENGTH_SHORT).show();
    }
    public void showExit() {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Exit confirmation");
        builder.setMessage("Really want for break?");
        builder.setCancelable(false);
        builder.setPositiveButton("Yes", (dialogInterface, i) -> finishAffinity());
        builder.setNegativeButton("Not yet", (dialogInterface, i) -> dialogInterface.cancel());
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("img_1", rnd1);
        outState.putInt("img_2", rnd2);
        outState.putInt("count", count);
        outState.putInt("checkPause", checkPause);
        outState.putString ("list_0", list[0]);
        outState.putString ("list_1", list[1]);
        outState.putString ("list_2", list[2]);
        outState.putString ("list_3", list[3]);
        outState.putString ("list_4", list[4]);
    }
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        rnd1 = savedInstanceState.getInt("img_1");
        rnd2 = savedInstanceState.getInt("img_2");
        count = savedInstanceState.getInt("count");
        checkPause = savedInstanceState.getInt("checkPause");
        list[0] = savedInstanceState.getString("list_0");
        list[1] = savedInstanceState.getString("list_1");
        list[2] = savedInstanceState.getString("list_2");
        list[3] = savedInstanceState.getString("list_3");
        list[4] = savedInstanceState.getString("list_4");
    }
}